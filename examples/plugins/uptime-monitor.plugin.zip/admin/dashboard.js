// examples/plugins/uptime-monitor/admin/dashboard.tsx
import { useCallback, useEffect, useState } from "react";
import {
  Alert,
  Button,
  Card,
  Heading,
  Stack,
  Text
} from "@pagebuilder/host-ui";
import { usePluginRoutes } from "@pagebuilder/host-hooks";
import { definePluginAdminApp } from "@pagebuilder/plugin-sdk";
import { jsx, jsxs } from "react/jsx-runtime";
function UptimeDashboard() {
  const routes = usePluginRoutes();
  const [status, setStatus] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await routes.fetch("status");
      const body = await res.json();
      setStatus(body);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load status");
    } finally {
      setLoading(false);
    }
  }, [routes]);
  useEffect(() => {
    refresh();
    const id = setInterval(() => void refresh(), 15000);
    return () => clearInterval(id);
  }, [refresh]);
  return /* @__PURE__ */ jsxs(Stack, {
    gap: 16,
    children: [
      /* @__PURE__ */ jsx(Heading, {
        level: 2,
        children: "Uptime Monitor"
      }),
      /* @__PURE__ */ jsxs(Text, {
        variant: "muted",
        children: [
          "Configured URLs are checked every 5 minutes. Edit the list and thresholds in ",
          /* @__PURE__ */ jsx("strong", {
            children: "Settings"
          }),
          ". Use ",
          /* @__PURE__ */ jsx("strong", {
            children: "Schedules"
          }),
          " to see the next run or fire one immediately."
        ]
      }),
      error && /* @__PURE__ */ jsx(Alert, {
        tone: "danger",
        title: "Could not load status",
        children: error
      }),
      !status && loading && /* @__PURE__ */ jsx(Text, {
        variant: "muted",
        children: "Loading…"
      }),
      status && status.urls.length === 0 && /* @__PURE__ */ jsxs(Alert, {
        tone: "info",
        title: "No URLs configured",
        children: [
          "Open ",
          /* @__PURE__ */ jsx("strong", {
            children: "Settings"
          }),
          " on the plugin card and add a URL from one of the allowlisted hosts (httpbin.org, example.com, api.github.com)."
        ]
      }),
      status && status.urls.length > 0 && /* @__PURE__ */ jsx(Stack, {
        gap: 12,
        children: status.urls.map((row) => /* @__PURE__ */ jsx(UrlCard, {
          row
        }, row.url))
      }),
      /* @__PURE__ */ jsx(Stack, {
        direction: "row",
        gap: 8,
        children: /* @__PURE__ */ jsx(Button, {
          variant: "secondary",
          size: "sm",
          onClick: () => void refresh(),
          disabled: loading,
          children: loading ? "Refreshing…" : "Refresh now"
        })
      }),
      status && /* @__PURE__ */ jsxs(Text, {
        variant: "muted",
        children: [
          "Last refreshed ",
          new Date(status.generated_at).toLocaleTimeString(),
          "."
        ]
      })
    ]
  });
}
function UrlCard({ row }) {
  const last = row.last;
  const tone = !last ? "info" : last.ok ? "success" : "danger";
  return /* @__PURE__ */ jsx(Card, {
    padding: 16,
    children: /* @__PURE__ */ jsxs(Stack, {
      gap: 8,
      children: [
        /* @__PURE__ */ jsxs(Stack, {
          direction: "row",
          gap: 8,
          children: [
            /* @__PURE__ */ jsx(Heading, {
              level: 4,
              children: row.url
            }),
            /* @__PURE__ */ jsx(Badge, {
              tone,
              children: last ? last.ok ? "Up" : "Down" : "Pending"
            })
          ]
        }),
        last && /* @__PURE__ */ jsx(Stack, {
          gap: 4,
          children: /* @__PURE__ */ jsxs(Text, {
            variant: "muted",
            children: [
              "Last check ",
              new Date(last["checked-at"]).toLocaleString(),
              " —",
              " ",
              last.ok ? `HTTP ${last["status-code"]} in ${last["latency-ms"]}ms` : `failed: ${last.error ?? "unknown"}`
            ]
          })
        }),
        /* @__PURE__ */ jsx(Stack, {
          gap: 4,
          children: /* @__PURE__ */ jsxs(Text, {
            children: [
              /* @__PURE__ */ jsx("strong", {
                children: "Last 24h:"
              }),
              " ",
              row.last24h.ok,
              " ok / ",
              row.last24h.failed,
              " failed (",
              row.last24h.uptime_pct ?? "—",
              "% uptime, avg",
              " ",
              row.last24h.avg_latency_ms,
              "ms over ",
              row.last24h.checks,
              " checks)"
            ]
          })
        })
      ]
    })
  });
}
function Badge({ tone, children }) {
  const styles = {
    display: "inline-block",
    padding: "2px 8px",
    fontSize: 11,
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "0.05em",
    borderRadius: 4,
    background: tone === "success" ? "var(--editor-success-bg)" : tone === "danger" ? "var(--editor-danger-bg)" : "var(--panel-border)",
    color: tone === "success" ? "var(--editor-success-green)" : tone === "danger" ? "var(--editor-danger)" : "var(--editor-text-muted)"
  };
  return /* @__PURE__ */ jsx("span", {
    style: styles,
    children
  });
}
var dashboard_default = definePluginAdminApp(UptimeDashboard);
export {
  dashboard_default as default
};
