// examples/plugins/analytics/frontend/tracker.ts
var PLUGIN_ID = "pagebuilder.analytics";
var ROUTE_BASE = `/admin/api/cms/plugins/${PLUGIN_ID}/runtime`;
var VISITOR_KEY = "__pb_analytics_v";
var SESSION_KEY = "__pb_analytics_s";
var GEO_CACHE_KEY = "__pb_analytics_geo";
var ADMIN_CACHE_KEY = "__pb_analytics_admin";
var OPT_OUT_KEY = "__pb_analytics_optout";
(function init() {
  const dnt = typeof navigator !== "undefined" && navigator.doNotTrack === "1" || typeof window !== "undefined" && window.doNotTrack === "1";
  if (dnt)
    return;
  try {
    if (localStorage.getItem(OPT_OUT_KEY) === "1")
      return;
  } catch {}
  function rid() {
    return (Math.random().toString(36).slice(2) + Date.now().toString(36)).slice(0, 16);
  }
  function visitorId() {
    try {
      const existing = localStorage.getItem(VISITOR_KEY);
      if (existing)
        return existing;
      const fresh = rid();
      localStorage.setItem(VISITOR_KEY, fresh);
      return fresh;
    } catch {
      return rid();
    }
  }
  function sessionId() {
    try {
      const existing = sessionStorage.getItem(SESSION_KEY);
      if (existing)
        return existing;
      const fresh = rid();
      sessionStorage.setItem(SESSION_KEY, fresh);
      return fresh;
    } catch {
      return rid();
    }
  }
  const _visitorId = visitorId();
  const _sessionId = sessionId();
  let cachedCountry = "";
  let cachedIsAdmin = false;
  let adminResolved = false;
  try {
    cachedCountry = sessionStorage.getItem(GEO_CACHE_KEY) ?? "";
  } catch {}
  try {
    const cached = sessionStorage.getItem(ADMIN_CACHE_KEY);
    if (cached !== null) {
      cachedIsAdmin = cached === "1";
      adminResolved = true;
    }
  } catch {}
  function fetchCountry() {
    if (cachedCountry)
      return;
    fetch(`${ROUTE_BASE}/geo`, { method: "GET", credentials: "omit" }).then((r) => r.json()).then((data) => {
      const country = typeof data.country === "string" ? data.country : "";
      cachedCountry = country;
      try {
        sessionStorage.setItem(GEO_CACHE_KEY, country);
      } catch {}
    }).catch(() => {});
  }
  function fetchIsAdmin() {
    if (adminResolved)
      return;
    fetch(`${ROUTE_BASE}/is-admin`, { method: "GET", credentials: "include" }).then((r) => r.json()).then((data) => {
      cachedIsAdmin = data.admin === true;
      adminResolved = true;
      try {
        sessionStorage.setItem(ADMIN_CACHE_KEY, cachedIsAdmin ? "1" : "0");
      } catch {}
    }).catch(() => {
      cachedIsAdmin = false;
      adminResolved = true;
    });
  }
  fetchCountry();
  fetchIsAdmin();
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  function send(eventName, payload = {}) {
    const body = JSON.stringify({
      eventName,
      payload,
      visitorId: _visitorId,
      sessionId: _sessionId,
      pagePath: location.pathname,
      referrer: document.referrer || null,
      country: cachedCountry,
      isAdmin: cachedIsAdmin,
      userAgent: ua,
      clientTime: new Date().toISOString()
    });
    fetch(`${ROUTE_BASE}/ingest`, {
      method: "POST",
      credentials: "omit",
      headers: { "Content-Type": "application/json" },
      keepalive: true,
      body
    }).catch(() => {});
  }
  window.__pb_analytics = {
    visitorId: _visitorId,
    sessionId: _sessionId,
    send
  };
  let pageStartTime = Date.now();
  let interactionCount = 0;
  function bumpInteraction() {
    interactionCount++;
  }
  document.addEventListener("click", bumpInteraction, { passive: true, capture: true });
  document.addEventListener("keypress", bumpInteraction, { passive: true, capture: true });
  document.addEventListener("scroll", bumpInteraction, { passive: true, capture: true, once: true });
  function firePageView() {
    pageStartTime = Date.now();
    interactionCount = 0;
    send("page-view", { path: location.pathname, title: document.title });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", firePageView, { once: true });
  } else {
    firePageView();
  }
  document.addEventListener("click", (e) => {
    const target = e.target;
    const anchor = target?.closest?.("a[href]");
    if (!anchor)
      return;
    const href = anchor.getAttribute("href") ?? "";
    let outbound = false;
    try {
      outbound = href.startsWith("http") && new URL(href).hostname !== location.hostname;
    } catch {}
    send("link-click", {
      href,
      text: (anchor.textContent ?? "").trim().slice(0, 80),
      outbound
    });
  }, { capture: true });
  const seenDepth = {};
  window.addEventListener("scroll", () => {
    const pct = Math.round((window.scrollY + window.innerHeight) / document.documentElement.scrollHeight * 100);
    for (const t of [25, 50, 75, 100]) {
      if (pct >= t && !seenDepth[t]) {
        seenDepth[t] = true;
        send("scroll-depth", { depth: t, path: location.pathname });
      }
    }
  }, { passive: true });
  const vitals = { lcp: null, cls: 0, fid: null };
  if (typeof PerformanceObserver !== "undefined") {
    try {
      const lcpObs = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const last = entries[entries.length - 1];
        if (last)
          vitals.lcp = Math.round(last.startTime);
      });
      lcpObs.observe({ type: "largest-contentful-paint", buffered: true });
    } catch {}
    try {
      const clsObs = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          const e = entry;
          if (!e.hadRecentInput && typeof e.value === "number")
            vitals.cls += e.value;
        }
      });
      clsObs.observe({ type: "layout-shift", buffered: true });
    } catch {}
    try {
      const fidObs = new PerformanceObserver((list) => {
        const first = list.getEntries()[0];
        if (first && vitals.fid === null && first.processingStart !== undefined) {
          vitals.fid = Math.round(first.processingStart - first.startTime);
        }
      });
      fidObs.observe({ type: "first-input", buffered: true });
    } catch {}
  }
  function flushVitals() {
    if (vitals.lcp === null && vitals.cls === 0 && vitals.fid === null)
      return;
    send("web-vitals", {
      lcp: vitals.lcp,
      cls: Math.round(vitals.cls * 1000) / 1000,
      fid: vitals.fid,
      path: location.pathname
    });
  }
  function flushBounce() {
    if (interactionCount === 0 && Date.now() - pageStartTime < 1e4) {
      send("bounce", { path: location.pathname });
    }
  }
  function onPageHide() {
    flushVitals();
    flushBounce();
  }
  window.addEventListener("pagehide", onPageHide, { capture: true, once: true });
  window.addEventListener("beforeunload", onPageHide, { capture: true, once: true });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden")
      flushVitals();
  });
})();
